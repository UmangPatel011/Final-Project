import { Component } from '@angular/core';

@Component({
  selector: 'app-default-dashboard',
  templateUrl: './default-dashboard.component.html',
  styleUrl: './default-dashboard.component.scss'
})
export class DefaultDashboardComponent {

}
