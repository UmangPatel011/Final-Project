module.exports.authService = require('./auth.service');
module.exports.emailService = require('./email.service');
module.exports.tokenService = require('./token.service');
module.exports.userService = require('./user.service');
module.exports.incomeService = require('./income.service');
module.exports.budgetService = require('./budget.service');
//module.exports.expenseService = require('./expense.service');
